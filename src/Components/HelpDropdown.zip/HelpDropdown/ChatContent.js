import { LeftOutlined, MessageFilled, SendOutlined } from "@ant-design/icons";
import { Button, Input } from "antd";
import React from "react";
import HelpContent from "./HelpContent";

const ChatContent = ({ onChangeComponent }) => {
  return (
    <div className="chatContent">
      <div className="chatContentHeader">
        <div className="chatContentHeaderDiv1">
          <LeftOutlined
            onClick={() =>
              onChangeComponent(
                <HelpContent handleComponentChange={onChangeComponent} />
              )
            }
          />
          <p style={{}}>Main Menu</p>
        </div>
        <div className="chatContentHeaderDiv2" style={{}}>
          <p>Live Chat</p>
          <MessageFilled />
        </div>
      </div>
      <div className="chatContentInput">
        <Input placeholder="Type message here" />
        <Button className="btn">
          <SendOutlined />
        </Button>
      </div>
    </div>
  );
};

export default ChatContent;
