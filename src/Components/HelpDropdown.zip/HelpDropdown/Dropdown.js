import React, { useState } from "react";
import HelpContent from "./HelpContent";
import HelpHeader from "./HelpHeader";
import Feedback from "./Feedback";
import { Button, Popover } from "antd";
import { MessageOutlined } from "@ant-design/icons";
import "./dropdown.css";

const Dropdown = () => {
  const [open, setOpen] = useState(false);

  function handleComponentChange(newComponent) {
    setCurrentComponent(newComponent);
  }
  const onFeedbackClosed = () => {
    setCurrentComponent(
      <HelpContent
        handleComponentChange={handleComponentChange}
        feedbackClosed={onFeedbackClosed}
      />
    );
  };
  const fun = () => {
    setOpen(!open);
    onFeedbackClosed();
  };

  const [currentComponent, setCurrentComponent] = useState(
    <HelpContent
      handleComponentChange={handleComponentChange}
      feedbackClosed={onFeedbackClosed}
    />
  );

  return (
    <div className="dropDown">
      <Popover
        content={
          <div className="chatPopup">
            {currentComponent.key !== "feedback" ? (
              <div>
                <HelpHeader setOpen={fun} />
                <div className="chatPopupContent">{currentComponent}</div>
              </div>
            ) : (
              <Feedback onChangeComponent={onFeedbackClosed} setOpen={fun} />
            )}
          </div>
        }
        placement="left"
        trigger="click"
        open={open}
      >
        <Button shape="circle" onClick={fun}>
          <MessageOutlined style={{ fontSize: "25px", color: "white" }} />
        </Button>
      </Popover>
    </div>
  );
};

export default Dropdown;
