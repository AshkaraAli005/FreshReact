import React from "react";
import { List } from "antd";
import {
  CalendarOutlined,
  CrownOutlined,
  ProfileOutlined,
  ReconciliationOutlined,
  RightOutlined,
  UserOutlined,
} from "@ant-design/icons";
import ChatContent from "./ChatContent";
import Feedback from "./Feedback";

const ChatList = ({ onChangeComponent, feedbackClosed }) => {
  const data = [
    {
      icon: <UserOutlined />,
      name: "Account",
      link: "Profile",
      component: <h3>Account</h3>,
    },
    {
      icon: <ReconciliationOutlined />,
      name: "Assessment",
      link: "Assessments",
      component: <h3>Assessment</h3>,
    },
    {
      icon: <CalendarOutlined />,
      name: "Consultation",
      link: "consultation",
      component: <h3>Consultations</h3>,
    },
    {
      icon: <ProfileOutlined />,
      name: "Health Records",
      link: "Health_Info",
      component: <h3>Health Records</h3>,
    },
    {
      icon: <CrownOutlined />,
      name: "Membership Plans",
      link: "SubcPlans",
      component: <h3>Plans</h3>,
    },
    {
      icon: <ProfileOutlined />,
      name: "Prescription",
      link: "Your_prescriptions",
      component: <h3>Prescriptions</h3>,
    },
    {
      icon: <ProfileOutlined />,
      name: "Feedback",
      link: "YourOrders",
      component: <Feedback key="feedback" onChangeComponent={feedbackClosed} />,
    },
    {
      icon: <ProfileOutlined />,
      name: "Help",
      link: "YourOrders",
      component: <ChatContent onChangeComponent={onChangeComponent} />,
    },
  ];
  return (
    <div className="lists">
      <List
      className="lists2"
        size="small"
        bordered
        style={{ borderRadius: "5px" }}
        dataSource={data}
        renderItem={(item) => (
          <List.Item style={{ backgroundColor: "#daf1da" }}>
            <div className="helpList">
              <div className="helpListContent">
                <div className="listIcon">{item.icon}</div>
                <div className="listName">{item.name}</div>
              </div>

              <RightOutlined
                onClick={() => onChangeComponent(item.component)}
                style={{ color: "gray" }}
              />
            </div>
          </List.Item>
        )}
      />
    </div>
  );
};
export default ChatList;
