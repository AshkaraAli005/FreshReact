import { LeftOutlined, MessageFilled } from "@ant-design/icons";
import { Button, Input, Tag } from "antd";
import React from "react";
import HelpContent from "./HelpContent";

const Questions = ({ onChangeComponent }) => {
  const Questions = [
    "This is Questions 1",
    "This is Questions 2",
    "This is Questions 3",
    "This is Questions 4",
    "This is Questions 5",
    "This is Questions 6",
    "Questions 7",
    "Questions 8",
    "Questions 9",
    "Questions 10",
  ];
  return (
    <div className="chatContent">
      <div className="chatContentHeader">
        <div className="chatContentHeaderDiv1">
          <LeftOutlined
            onClick={() =>
              onChangeComponent(
                <HelpContent handleComponentChange={onChangeComponent} />
              )
            }
          />
          <p>Main Menu</p>
        </div>
        <div className="chatContentHeaderDiv2" style={{}}>
          <p>Questions</p>
          <MessageFilled />
        </div>
      </div>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          height: "100%",
          padding: "2%",
          gap: "10px",
        }}
      >
        <div>
          <Input.TextArea
            style={{ width: "100%", height: "8vh", resize: "none" }}
            placeholder="Ask your Questions.."
          ></Input.TextArea>
          <div>
            <h3 style={{ margin: "2% 0%" }}>Frequently asked questions:</h3>
            <div style={{ padding: "0% 4%" }}>
              {Questions.map((item) => (
                <Tag style={{}} onClick={() => {}}>
                  <span
                    style={{
                      display: "flex",
                      height: "30px",
                      gap: "40px",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {item}
                  </span>
                </Tag>
              ))}
            </div>
          </div>
        </div>
        <Button className="ask-qn-btn" style={{ color: "white" }}>
          Submit
        </Button>
      </div>
    </div>
  );
};

export default Questions;
