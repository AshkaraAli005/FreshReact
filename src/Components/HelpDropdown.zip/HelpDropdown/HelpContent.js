import React from "react";
import ChatList from "./HelpChatList";
import { Button } from "antd";
import Questions from "./Questions";

const HelpContent = ({ handleComponentChange, feedbackClosed }) => {
  return (
    <div className="helpContent">
      <p>Hello ask me a question or Select one Below.</p>
      <h3>How can we Help you ?</h3>

      <ChatList
        onChangeComponent={handleComponentChange}
        feedbackClosed={feedbackClosed}
      />
      <div className="qnBtnDiv">
        <Button
          className="ask-qn-btn"
          style={{color:"white"}}
          onClick={() =>
            handleComponentChange(
              <Questions onChangeComponent={handleComponentChange} />
            )
          }
        >
          Ask Question
        </Button>
      </div>
    </div>
  );
};

export default HelpContent;
