import { CheckCircleFilled } from "@ant-design/icons";
import { faL } from "@fortawesome/free-solid-svg-icons";
import { Button, Modal } from "antd";
import React, { useState } from "react";

const Modal1 = () => {
    
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  return (
    <div className="modal1">
      <Button type="primary" onClick={showModal}>
        Open Modal
      </Button>
      <Modal title="Testing video & Audio" open={isModalOpen} footer={[]} width={400} onCancel={handleCancel} closable={false}>
        <div className="modalContent">
          <div className="modaldiv1">Checking for video and audio feeds.</div>
          <div className="modaldiv2">
            <div>Video feed</div>
            <div>
              <CheckCircleFilled />
            </div>
          </div>
          <div className="modaldiv2">
            <div>Audio feed</div>
            <div>
              <CheckCircleFilled />
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Modal1;
