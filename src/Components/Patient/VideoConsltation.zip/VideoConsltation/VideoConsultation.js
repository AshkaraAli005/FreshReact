import { CheckCircleOutlined, LeftCircleOutlined } from "@ant-design/icons";
import { Button } from "antd";
import React from "react";
import "./VideoConsultation.css";
import chatIcon from "./Assets/chat1.svg";
import FlipCamIcon from "./Assets/flip 1.svg";
import CameraIcon from "./Assets/vCamera.svg";
import MicIcon from "./Assets/mic.svg";
import CallCut from "./Assets/Frame 4104.svg";

const VideoConsultation = () => {
  return (
    <div className="vid-Consultation">
      <div className="headerContent">
        <div className="DocDetails">
          <LeftCircleOutlined /> Dr.Babu . Clinical Psychology
        </div>
        <Button className="btn">
          <CheckCircleOutlined /> Finish Consultation
        </Button>
      </div>
      <div>
        <div className="video-container">
          <div className="call-Details">
            <div className="div1">
              <div>Live consultation </div>
              <div className="timer">00.00</div>
            </div>
            <div className="div2">
              Please wait for Dr. Srikanth Srinivas to join..
            </div>
            <div className="div3">
              <img src="24-hours-support 2.svg" />
            </div>
          </div>
          <div className="video-section">
            <div className="video-icons">
              <div>
                <img src={MicIcon} className="icons" />
              </div>
              <div>
                <img src={CameraIcon} className="icons camera" />
              </div>
              <div>
                <img src={FlipCamIcon} className="icons " />
              </div>
              <div>
                <img src={chatIcon} className="icons" />
              </div>
              <div>
                <img src={CallCut} className="icons call-end" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoConsultation;
